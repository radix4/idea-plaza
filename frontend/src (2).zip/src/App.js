import React from 'react'
import IdeaPage from './components/IdeaPage'

const App = () => {
  return <IdeaPage />
}

export default App
